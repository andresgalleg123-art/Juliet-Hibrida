from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.clock import mainthread
from kivy.network.urlrequest import UrlRequest
import json
import os
from juliet_core import chat_reply

KV = '''
<ChatScreen>:
    orientation: 'vertical'
    padding: 8
    spacing: 8

    BoxLayout:
        size_hint_y: None
        height: '48dp'
        Label:
            text: 'Juliet Híbrida'
            font_size: '20sp'
    ScrollView:
        id: scroll
        do_scroll_x: False
        GridLayout:
            id: messages
            cols: 1
            size_hint_y: None
            height: self.minimum_height

    BoxLayout:
        size_hint_y: None
        height: '56dp'
        spacing: 8
        TextInput:
            id: input_text
            hint_text: 'Mensaje...'
            multiline: False
        Button:
            text: 'Enviar'
            size_hint_x: None
            width: '100dp'
            on_release: root.on_send()
'''

class ChatScreen(BoxLayout):
    # If you want remote backend, set this to your public URL e.g. 'https://your-app.koyeb.app'
    server_url = None

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def add_message(self, text, from_user=True):
        from kivy.uix.label import Label
        lbl = Label(text=text, size_hint_y=None, height='36dp', halign='left' if from_user else 'left', valign='middle')
        lbl.text_size = (self.width - 32, None)
        self.ids.messages.add_widget(lbl)
        from kivy.clock import Clock
        Clock.schedule_once(lambda dt: self.ids.scroll.scroll_to(lbl), 0.05)

    def on_send(self):
        txt = self.ids.input_text.text.strip()
        if not txt:
            return
        self.add_message("[Tú] " + txt, from_user=True)
        self.ids.input_text.text = ""
        if self.server_url:
            headers = {'Content-Type': 'application/json'}
            body = json.dumps({"message": txt})
            UrlRequest(self.server_url + '/chat', req_body=body, req_headers=headers, on_success=self.on_remote_success, on_error=self.on_remote_error, on_failure=self.on_remote_error)
        else:
            res = chat_reply(txt)
            self.add_message("[Juliet] " + res['response'], from_user=False)

    @mainthread
    def on_remote_success(self, req, result):
        try:
            r = result
            if isinstance(r, bytes):
                r = json.loads(r.decode('utf-8'))
        except Exception:
            pass
        text = r.get('response') if isinstance(r, dict) else str(r)
        self.add_message("[Juliet] " + str(text), from_user=False)

    @mainthread
    def on_remote_error(self, req, error):
        self.add_message("[Juliet] Error de conexión al backend.", from_user=False)

class JulietApp(App):
    def build(self):
        Builder.load_string(KV)
        screen = ChatScreen()
        # To enable remote backend by default, set URL below (uncomment and set):
        # screen.server_url = 'https://your-app.koyeb.app'
        return screen

if __name__ == '__main__':
    JulietApp().run()
