def chat_reply(msg):
    msg = (msg or '').strip()
    if not msg:
        return {'response':'No escribiste nada.','emotion':'neutral'}
    low = msg.lower()
    if 'hola' in low or 'buenas' in low:
        return {'response':'¡Hola! Soy Juliet en modo offline. Con internet puedo ayudarte más.','emotion':'happy'}
    if '?' in msg or any(w in low for w in ['como','qué','que','por qué','cuando']):
        return {'response':'Buena pregunta — dame más detalle y lo intento.', 'emotion':'question'}
    if len(msg.split()) < 6:
        return {'response':f'Interesante: "{msg}". ¿Quieres que lo explique?', 'emotion':'neutral'}
    return {'response':'Entendido. ' + msg[:200], 'emotion':'neutral'}
