Juliet Híbrida - proyecto para compilar APK via GitHub Actions

HOW TO USE (mobile-friendly):
1) Create a GitHub repo (public) and upload the contents of this ZIP's 'app' folder plus files at root.
2) In the repo create directory .github/workflows and add the workflow.yml content (this file is included in the ZIP).
3) Trigger the workflow in GitHub Actions (Actions tab -> select the workflow -> Run workflow).
4) Wait (15-60 minutes). When finished, download the APK from the workflow artifact and install on your Redmi 12.

NOTES:
- Buildozer on GitHub runners may require additional config (NDK/SDK). If the workflow fails, I'll provide a ready-to-use adjusted workflow or we can use a prebuilt CI image.
- The APK uses offline local chat and can call a remote backend if you set server_url in main.py.
